package ru.spring.looc.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller 
public class CalcController {


    @GetMapping("/")
    public String start(Model model, @RequestParam(value = "b1",required = false,defaultValue = "0")double a1,@RequestParam(value = "b2",required = false,defaultValue = "0")double a2,@RequestParam(value = "dei2",required = false,defaultValue = "0")int dei ) {
        double res = 0;
        if (dei==1){res=a1+a2;}
        if (dei==2){res=a1-a2;}
        if (dei==3){res=a1*a2;}
        if (dei==4){res=a1/a2;}
        if (dei==0){res=0;}
        model.addAttribute("res",res);
        return "Calc";
    }
    @PostMapping("/")
    public String Cal(Model model, @RequestParam(value = "a1",required = false,defaultValue = "0")double a1,@RequestParam(value = "a2",required = false,defaultValue = "0")double a2,@RequestParam(value = "dei",required = false,defaultValue = "0")int dei ){
        double res=0;
        if (dei==1){res=a1+a2;}
        if (dei==2){res=a1-a2;}
        if (dei==3){res=a1*a2;}
        if (dei==4){res=a1/a2;}
        if (dei==0){res=0;}
        model.addAttribute("res",res);
        return "Calc";
    }
}
